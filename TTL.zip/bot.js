const { Client, LocalAuth } = require('whatsapp-web.js');
const qrcode = require('qrcode-terminal');
const collegeInfo = require('./data/collegeInfo.json');

const client = new Client({
    authStrategy: new LocalAuth(),
});

client.on('qr', (qr) => {
    qrcode.generate(qr, { small: true });
});

client.on('authenticated', () => {
    console.log('✅ Client authenticated!');
});

client.on('ready', () => {
    console.log('✅ Client is ready!');
});

client.on('disconnected', () => {
    console.log('❌ Client disconnected!');
});

client.on('auth_failure', () => {
    console.log('❌ Authentication failed!');
});

const sendReply = async (msg, replyText) => {
    const options = {};
    if (msg.hasQuotedMsg) {
        try {
            const quoted = await msg.getQuotedMessage();
            options.quotedMessageId = quoted.id._serialized;
        } catch (err) {
            console.error('⚠️ Failed to get quoted message:', err.message);
        }
    }

    try {
        await client.sendMessage(msg.from, replyText, options);
    } catch (err) {
        console.error('❌ Failed to send message:', err.message);
    }
};

client.on('message', async (message) => {
    const msg = message.body.toLowerCase();

    if (!msg.startsWith(".")) return;
    console.log(`📩 Received command: ${msg}`);

    switch (msg) {
        case '.help':
            await sendReply(message,
                "🤖 *DYPCET Bot Commands:*\n\n" +
                "• `.about` – About the college\n" +
                "• `.courses` – UG & PG Courses\n" +
                "• `.placement` – Placement stats\n" +
                "• `.contact` – Contact info\n" +
                "• `.website` – Official website\n" +
                "• `.code` – Institute code\n" +
                "• `.help` – Show this help message"
            );
            break;

        case '.about':
            await sendReply(message, collegeInfo.about);
            break;

        case '.courses':
            let response = '*🎓 Undergraduate Courses:*\n';
            collegeInfo.courses.undergraduate.forEach(course => {
                response += `• ${course.name} (Intake: ${course.intake})\n`;
            });

            response += '\n*📘 Postgraduate Courses:*\n';
            collegeInfo.courses.postgraduate.forEach(course => {
                response += `• ${course.name} (Intake: ${course.intake})\n`;
            });

            await sendReply(message, response);
            break;

        case '.placement':
            const p = collegeInfo.placements["2023-24"];
            await sendReply(message,
                `📊 *Placement Stats 2023-24:*\n` +
                `• Companies: ${p.companies_participated}\n` +
                `• Single Offers: ${p.single_offers}\n` +
                `• Multiple Offers: ${p.multiple_offers}\n` +
                `• Total Placed: ${p.total_students_placed}\n` +
                `• Offers: ${p.total_job_offers}\n` +
                `• Highest: ₹${p.highest_salary_lpa} LPA\n` +
                `• Average: ₹${p.average_salary_lpa} LPA\n` +
                `• Median: ₹${p.median_salary_lpa} LPA`
            );
            break;

        case '.contact':
            const c = collegeInfo.contact;
            await sendReply(message,
                `📞 *Contact Info:*\n` +
                `• Phone: ${c.phone.join(", ")}\n` +
                `• Email: ${c.email}\n` +
                `• Careers: ${c.careers_email}\n` +
                `• Address: ${c.address}`
            );
            break;

        case '.website':
            await sendReply(message, `🌐 Official Website: ${collegeInfo.website}`);
            break;

        case '.code':
            await sendReply(message, `🏷️ Institute Code: ${collegeInfo.institute_code}`);
            break;

        default:
            await sendReply(message, "❓ Unknown command. Type `.help` for a list of valid commands.");
    }
});

client.initialize();
